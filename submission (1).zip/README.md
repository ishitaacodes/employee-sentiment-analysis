# 📊 Employee Sentiment Analysis

**Author:** [Your Name]
**Most recent month analyzed:** 2011-12

## Summary (auto-generated)
**Top 3 Positive employees (most recent month):** eric.bass@enron.com, patti.thompson@enron.com, lydia.delgado@enron.com
**Top 3 Negative employees (most recent month):** johnny.palmer@enron.com, bobette.riner@ipgdirect.com, john.arnold@enron.com

**Flight risks (>=4 negative msgs in rolling 30 days):** bobette.riner@ipgdirect.com, don.baughman@enron.com, john.arnold@enron.com, johnny.palmer@enron.com, kayne.coulter@enron.com, sally.beck@enron.com

**Predictive model metrics:** MSE = 1.95, R² = 0.83

## Quick instructions
- Open `notebook.ipynb` to reproduce the analysis in Colab
- Visualizations are in `/visualization/`
- Full report: `Final_Report.docx`